﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DomaciBaze
{
    public partial class Form1 : Form
    {
        public int red = 0;
        DataTable studenti = new DataTable();
        string CS = "Data source=DESKTOP-685L8RG\\SQLEXPRESS; Initial catalog=fakultet_baza; integrated security=true";
        public Form1()
        {
            InitializeComponent();
        }

        private void refresh()
        {
            if(studenti.Rows.Count == 0)
            {
                txt_id.Text = "";
                txt_indeks.Text = "";
                txt_ime.Text = "";
                txt_prezime.Text = "";
                txt_jmbg.Text = "";
                txt_redovan.Text = "";
                btn_prev.Enabled = false;
                btn_first.Enabled = false;
                btn_next.Enabled = false;
                btn_last.Enabled = false;
                btn_delete.Enabled = false;
                btn_change.Enabled = false;
                
            }
            else
            {
                txt_id.Text = Convert.ToString(studenti.Rows[red]["id"]);
                txt_indeks.Text = Convert.ToString(studenti.Rows[red]["brojIndeksa"]);
                txt_ime.Text = Convert.ToString(studenti.Rows[red]["ime"]);
                txt_prezime.Text = Convert.ToString(studenti.Rows[red]["prezime"]);
                txt_jmbg.Text = Convert.ToString(studenti.Rows[red]["jmbg"]);
                txt_redovan.Text = Convert.ToString(studenti.Rows[red]["redovan"]);

                btn_next.Enabled = (red != studenti.Rows.Count - 1);
                btn_last.Enabled = (red != studenti.Rows.Count - 1);

                btn_prev.Enabled = (red != 0);
                btn_first.Enabled = (red != 0);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            SqlConnection veza = new SqlConnection(CS);
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * from student order BY id", veza);
            adapter.Fill(studenti);
            refresh();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            red++;
            refresh();
        }

        private void btn_prev_Click(object sender, EventArgs e)
        {
            red--;
            refresh();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            red = studenti.Rows.Count - 1;
            refresh();
        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            red = 0;
            refresh();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string add = "INSERT INTO student (id, brojIndeksa, ime, prezime, jmbg, redovan) VALUES ("+ (studenti.Rows.Count+1) + ",'" + txt_indeks.Text + "','" + txt_ime.Text + "','" + txt_prezime.Text + "','" + txt_jmbg.Text + "','" + txt_redovan.Text + "')";
            SqlConnection veza = new SqlConnection(CS);
            SqlCommand naredba = new SqlCommand(add, veza);
            veza.Open();
            naredba.ExecuteNonQuery();
            veza.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * from student ORDER BY id", veza);
            studenti.Clear();
            adapter.Fill(studenti);
            red = studenti.Rows.Count - 1;
            refresh();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string del = "DELETE from student where id = " + txt_id.Text;
            SqlConnection veza = new SqlConnection(CS);
            SqlCommand naredba = new SqlCommand(del, veza);
            veza.Open();
            naredba.ExecuteNonQuery();
            veza.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * from student ORDER BY id", veza);
            studenti.Clear();
            adapter.Fill(studenti);
            if (red > studenti.Rows.Count - 1)
            {
                red = studenti.Rows.Count - 1;  
            }
            refresh();
        }

        private void btn_change_Click(object sender, EventArgs e)
        {
            string chng = "UPDATE student SET brojIndeksa='" + txt_indeks.Text + "', ime = '" + txt_ime.Text + "', prezime = '" + txt_prezime.Text + "', jmbg = '" + txt_jmbg.Text + "', redovan = '" + txt_redovan.Text + "' WHERE id = "+txt_id.Text;
            SqlConnection veza = new SqlConnection(CS);
            SqlCommand naredba = new SqlCommand(chng, veza);
            veza.Open();
            naredba.ExecuteNonQuery();
            veza.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * from student ORDER BY id", veza);
            studenti.Clear();
            adapter.Fill(studenti);
            refresh();
        }
    }
}
